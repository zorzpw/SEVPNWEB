<?php
/* 本文件由系统自动生成 如非必要 请勿修改 */
define("_host_","localhost");
define("_user_","root");
define("_pass_","root");
define("_port_","3306");
define("_ov_","ov");
define("_openvpn_","openvpn");
define("_iuser_","iuser");
define("_ipass_","pass");
define("_isent_","isent");
define("_irecv_","irecv");
define("_starttime_","starttime");
define("_endtime_","endtime");
define("_maxll_","maxll");
define("_other_","dlid,tian");
define("_i_","i");
