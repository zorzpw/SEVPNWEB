<?php
/*
	测试账号申请
*/
include("../api.inc.php");
$title='流量统计';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>

   <body>
      <?php
	  $list=$DB->query("SELECT * FROM `openvpn`");
	  $i = 0;
	  $j = 0;
	  while($vo = $DB->fetch($list)){
		  $count += $vo['maxll']; // 总计流量
		  $send += $vo['isent']; //发送流量
		  $recv += $vo['irecv']; //接收流量
		  
			if($vo['i'] != '1'){
				$j++;
			}
		  
		  $i++;
	  }
	  
	  $fenpei = $count/1024/1024;  //总计分配
	  $fasong = $send/1024/1024;  //总计发送
	  $jieshou = $recv/1024/1024;  //总计接收
	
	  $shiyong = ($send+$recv)/1024/1024;  //总计使用
	  $weiyong = ($count-$send-$recv)/1024/1024;  //总计未使用
	  //echo '服务器总共分配流量:'.round($MB['n'],2).$MB['p'];
	  ?>
	      <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
	        <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">数据流量统计</h3></div>
        <div class="panel-body">
   <div class="panel-body">
      <table class="table">
   <thead>
      <tr>
         <th>项目</th>
         <th>数值</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>总计已分配</td>
         <td><?php echo round($fenpei);?>MB</td>
      </tr>
	  <tr>
         <td>总计已发送</td>
         <td><?php echo round($fasong);?>MB</td>
      </tr> <tr>
         <td>总计已接收</td>
         <td><?php echo round($jieshou);?>MB</td>
      </tr> <tr>
         <td>总计已使用</td>
         <td><?php echo round($shiyong);?>MB</td>
      </tr> <tr>
         <td>总计剩余</td>
         <td><?php echo round($weiyong);?>MB</td>
      </tr> <tr>
         <td>总计统计人数</td>
         <td><?php echo $i; ?></td>
      </tr><tr>
         <td>总计禁用人数</td>
         <td><?php echo $j; ?></td>
      </tr>
      
   </tbody>
</table>
   </div>
</div>
</div>
   </body>
</html>