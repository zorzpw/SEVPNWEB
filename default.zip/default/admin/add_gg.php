<?php

    
    	function success_go($msg,$url){
		echo '<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">
                &times;
            </button>
            '.$msg.',系统将在3秒后跳转。<a href="'.$url.'">等不及了！</a>
        </div> ';
        echo '<script>setTimeout(function(){
        	window.location.href="'.$url.'";
        },3000)</script>';
	}
	function error_go($msg,$url){
		echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">
                &times;
            </button>
            '.$msg.',系统将在3秒后跳转。<a href="'.$url.'">等不及了！</a>
        </div> ';
        echo '<script>setTimeout(function(){
        	window.location.href="'.$url.'";
        },3000)</script>';
	}
	
 	include("../api.inc.php");
 	$title='发布公告';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
	include './nav.php';
	$id=$_GET['id'];
	$name=$_POST['name'];
	$content=$_POST['content'];
 	if($_GET['act'] == 'update'){
		//$db = db('app_gg');
		$sql=$DB->query("update `app_gg` set `name`='$name',`content`='$content' where `id`='$id'");
		if($sql){
			success_go("公告修改成功",'add_gg.php?act=mod&id='.$_GET['id']);
		}else{
			error_go("十分抱歉修改失败",'add_gg.php?act=mod&id='.$_GET['id']);
		}
		
	}elseif($_GET['act'] == 'add'){
		//$db = db('app_gg');
		$sql="insert into `app_gg` (`name`,`content`,`time`) values ('$name','$content','".time()."')";
		if($DB->query($sql)){
			success_go("新增消息【".$_POST['name']."】成功！",'add_gg.php');
		}else{
			error_go("十分抱歉修改失败",'add_gg.php');
		}
		
	}else{
	
	$action = '?act=add';
	if($_GET['act'] == 'mod'){
		$rs=$DB->query("SELECT * FROM `app_gg` WHERE `id`=$id");
		$info = $DB->fetch($rs);
		$action = "?act=update&id=".$_GET['id'];
	}
		
 ?>
 <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">公告/消息推送</h3></div>
<div class="panel-body">
	<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>" onsubmit="return checkStr()">
    <div class="form-group">
        <label for="firstname" class="col-sm-2 control-label">标题</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="name" placeholder="标题" value="<?php echo $info['name'] ?>">
        </div>
    </div>
    
    
    
    <div class="form-group" >
        <label for="name" class="col-sm-2 control-label">主要内容</label>
         <div class="col-sm-10"><textarea class="form-control" rows="10" name="content"><?php echo $info['content'] ?></textarea></div>
    </div>
    
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-default">提交数据</button>
        </div>
    </div>
</form> 
	</div>
	</div>
	</div>
	</div>
	<script>
	function checkStr(){
		var title = $('[name="title"]').val();
		var content = $('[name="content"]').val();
		if(title == "" || content ==　""){
			alert("标题与内容不得为空");
			return false;
		}
		return true;
	}
	</script>
<?php
	}
	include('footer.php');
	
?>
