<?php
$mod='blank';
include("../api.inc.php");
$title='服务器列表';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">删除服务器</h3></div>
<div class="panel-body box">';
$ip=$_GET['ip'];
$sql=$DB->query("DELETE FROM `server` WHERE ip='$ip'");
$sql=$DB->query("DELETE FROM `server_list` WHERE ip='$ip'");
if($sql){echo '删除成功！';}
else{echo '删除失败！';}
echo '<hr/><a href="./fwqlist.php">>>返回服务器列表</a></div></div>';
}

else
{

echo '<form action="fwqlist.php" method="get" class="form-inline">
  <div class="form-group">
    <label>搜索</label>
    <input type="text" class="form-control" name="kw" placeholder="服务器名称">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form>';


if(!empty($_GET['kw'])) {
	$sql=" `name`='{$_GET['kw']}'";
	$numrows=$DB->count("SELECT count(*) from `server` WHERE{$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个服务器';
}else{
	$numrows=$DB->count("SELECT count(*) from `server` WHERE 1");
	$sql=" 1";
	$con='平台共有 <b>'.$numrows.'</b> 个服务器';
}

echo $con;
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>服务器地址</th><th>下载流量</th><th>上传流量</th><th>在线人数</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM `server` WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
	if($res['ip']=="127.0.0.1"){
		$ipp="localhost";
	}else{
		$ipp=$res['ip'];
	}
	$online="离线";
	$server=$DB->query("select SUBSTRING_INDEX(host,':',1) as ip , count(*) from information_schema.processlist group by ip");
	while($re = $DB->fetch($server)){
		if($ipp==$re['ip']) {
			$online="在线";
			break;
		}
	}
?>
<tr>
<td><?=$res['ip']?></td>
<td><?=round($res['sent']/1024/1024)?>MB</td>
<td><?=round($res['recv']/1024/1024)?>MB</td>
<td><?=$res['online']?></td>
<td><?=$online?></td>
<td><a href="./fwqlist.php?my=del&ip=<?=$res['ip']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="fwqlist.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="fwqlist.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="fwqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="fwqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="fwqlist.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="fwqlist.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
  </div>