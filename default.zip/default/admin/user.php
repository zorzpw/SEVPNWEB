<?php

	include("../api.inc.php");
 	$title='管理设置';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
	include('./nav.php');
	
		$user=$_GET["user"];
		$pass=$_GET["pass"];
		$newpass=$_GET["newpass"];
	if($_GET["user"]){
		//$admin = db("app_admin")->where(array("username"=>$_SESSION["dd"]["username"],"password"=>$_SESSION["dd"]["password"]))->find();
		if($pass == $newpass){
			echo "<script>alert('不能修改为重复的密码');history.go(-1);</script>";
		}else{
			if($pass != $adminpass){
				echo "<script>alert('当前密码错误');history.go(-1);</script>";
			}else{
				if(trim($newpass) == ""){
					echo "<script>alert('密码不得为空');history.go(-1);</script>";
				}else{
					$sql=$DB->query("update `app_admin` set `username`='$user',`password`='$newpass'");
					if($sql){
						echo "<script>alert('密码修改成功');history.go(-1);</script>";
					}else{
						echo "<script>alert('无法更新数据到数据库');history.go(-1);</script>";
					}
				}
			}
		}
	}else{

 ?>
   
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">修改管理密码</h3></div>
<div class="panel-body">
	<!--表单内容-->
	<form action="./user.php" method="get" class="form-horizontal" role="form">
	<div class="input-group">
			  <span class="input-group-addon">用户名</span>
              <input type="text" name="user" value="<?php echo $admin["username"]?>" class="form-control" required/>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">当前密码</span>
			  <input type="text" name="pass" value="" class="form-control" required>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">新密码</span>
			  <input type="text" name="newpass" value="" class="form-control" required>
            </div><br/>
			<input type="submit" value="确认修改" class="btn btn-primary form-control"/>
  </form>
	</div>
</div>
</div>

<script>
$(function(){
	$(".mod").click(function(){
		$.post(
			"?act=mod",{
				"p1":$("#username").val(),
				"p2":$("#password").val(),
				"p3":$("#password_new").val()
			},function(data){
				if(data.status == "success"){
					alert("密码修改成功");
				}else{
					alert(data.msg);
				}
			},"JSON"
		);
	});
});
</script>


	<?php include('footer.php'); };?>