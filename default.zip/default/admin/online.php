<?php
$mod='blank';
include("../api.inc.php");
$title='当前在线用户';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';


?>
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="table-responsive">
<table class="table table-bordered">
   <thead>
		<thead><tr><th>用户名</th><th>上传流量</th><th>下载流量</th><th>登陆数</th></tr></thead>
         <tbody>
<?php
$rs=$DB->query("SELECT * FROM `openvpn` WHERE `online`<>'0'");
while($res = $DB->fetch($rs))
{ 
?>
<tr>
<td><?=$res['iuser']?></td>
<td><?=round($res['osent']/1024/1024)?>MB</td>
<td><?=round($res['orecv']/1024/1024)?>MB</td>
<td><?=$res['online']?></td>
</tr>
<?php }

?>
     </tbody>
   </thead>
</table>
      </div>
    </div>
  </div>
</body>
</html>