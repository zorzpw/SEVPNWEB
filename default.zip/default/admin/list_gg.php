<?php
	include("../api.inc.php");
 	$title='公告列表';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
	include('./nav.php');
 	if($_GET['act'] == 'del'){
		$id=$_POST['id'];
		$sql=$DB->query("DELETE FROM `app_gg` WHERE id='$id'");
		if($sql){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}elseif($_GET['act'] == 'show'){
		$show = $_POST['show'] == '1' ? "1" : "0";
		$id=$_POST['id'];
		$sql=$DB->query("update `app_gg` set `show`='$show' where `id`='$id'");
		if($sql){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}else{
 ?>
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">公告列表</h3></div>
<div class="panel-body">
	<ul class="list-group">
	<?php 
		//$db = db('app_gg');
		$list=$DB->query("SELECT * FROM `app_gg` order by id desc");
		while($vo = $DB->fetch($list)){
			echo ' <li class="list-group-item line-id-'.$vo['id'].'">
        <span class="badge">'.date('Y/m/d H:i:s',$vo['time']).'</span>
        ID:'.$vo['id'].':'.$vo['name'].'<br>
		<button type="button" class="btn btn-primary btn-xs" onclick="window.location.href=\'add_gg.php?act=mod&id='.$vo['id'].'\'">编辑</button>&nbsp;';
		echo '<button type="button" class="btn btn-danger btn-xs" onclick="delLine(\''.$vo['id'].'\')">删除</button>
    </li>';
		}
	?>
   
</ul>
</div>
</div>
</div>
</div>
<?php
	}
	include('footer.php');
	
?>
<script>
function qiyong(id){
	var doc = $('.line-id-'+id+' .showstatus');
	if(doc.attr('data') == "1"){
		doc.html("已禁用").attr({'data':'0'});
	}else{
		doc.html("已启用").attr({'data':'1'});
	}
	var url = "list_gg.php?act=show";
		var data = {
			"id":id,
			"show":doc.attr('data')
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("操作失败");
			}
		},"JSON");
}
function delLine(id){
	if(confirm('确认删除吗？删除后不可恢复哦！')){
		$('.line-id-'+id).slideUp();
		var url = "list_gg.php?act=del";
		var data = {
			"id":id
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("删除失败");
			}
		},"JSON");
	}
}
</script>