<?php

	
	function success_go($msg,$url){
		echo '<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">
                &times;
            </button>
            '.$msg.',系统将在3秒后跳转。<a href="'.$url.'">等不及了！</a>
        </div> ';
        echo '<script>setTimeout(function(){
        	window.location.href="'.$url.'";
        },3000)</script>';
	}
	function error_go($msg,$url){
		echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">
                &times;
            </button>
            '.$msg.',系统将在3秒后跳转。<a href="'.$url.'">等不及了！</a>
        </div> ';
        echo '<script>setTimeout(function(){
        	window.location.href="'.$url.'";
        },3000)</script>';
	}
	include("../api.inc.php");
	$title='线路列表';
	include './head.php';
	if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
	include('./nav.php');
 	if($_GET['act'] == 'del'){
		$id=$_POST['id'];
		$sql=$DB->query("DELETE FROM `line` WHERE id='$id'");
		if($sql){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}elseif($_GET['act'] == 'show'){
		$show = $_POST['show'] == '1' ? "1" : "0";
		$id=$_POST['id'];
		$sql=$DB->query("update `line` set `show`='$show' where `id`='$id'");
		if($sql){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}else{
 ?>
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">线路分类</h3></div>
<div class="panel-body">
<?php
$gid=$_GET["gid"];
if($_GET["gid"] == ""){
	$numrows=$DB->count("SELECT count(*) from `line`");
}else{
	$numrows=$DB->count("SELECT count(*) from `line` WHERE `group`=$gid");
}
$pagesize=20;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$list=1;

if($_GET["gid"] == ""){
	echo '&nbsp;&nbsp;&nbsp;&nbsp;<span class="label label-info" ><a href="?'.$t_str.'" style="color:#fff">全部</a></span>';
	$list=$DB->query("SELECT * FROM `line` order by id desc limit $offset,$pagesize");
}else{
	echo '&nbsp;&nbsp;&nbsp;&nbsp;<span ><a href="?'.$t_str.'" >全部</a></span>';
	$list=$DB->query("SELECT * FROM `line` WHERE `group`=$gid order by id desc limit $offset,$pagesize");
}
$rs=$DB->query("SELECT * FROM `line_grop`");
while($res = $DB->fetch($rs))
{
	if($res['id'] == $_GET["gid"]){
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<span class="label label-info" ><a href="?gid='.$res["id"].'" style="color:#fff">'.$res['name'].'</a></span>';
	}else{
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="?gid='.$res["id"].'">'.$res['name'].'</a></span>';
	}
}
?>
<div style="clear:both;height:10px;"></div>
	<ul class="list-group">
	<?php 
		
		
		while($vo = $DB->fetch($list)){
			echo ' <li class="list-group-item line-id-'.$vo['id'].'">
        <span class="badge">'.$vo['type'].'</span>
        ID:'.$vo['id'].':'.$vo['name'].'
		<p>'.$vo["label"].'</p>
		<button type="button" class="btn btn-primary btn-xs" onclick="window.location.href=\'add_line.php?act=mod&id='.$vo['id'].'\'">编辑</button>&nbsp;';
		echo $vo['show'] == '1'? '<button type="button" class="btn btn-primary btn-xs showstatus" onclick="qiyong(\''.$vo['id'].'\')" data="1">已启用</button>&nbsp;':'<button type="button" class="btn btn-primary btn-xs showstatus" onclick="qiyong(\''.$vo['id'].'\')" data="0">已禁用</button>&nbsp;';
		echo '<button type="button" class="btn btn-danger btn-xs" onclick="delLine(\''.$vo['id'].'\')">删除</button>
    </li>';
		}
	?>
   
</ul><?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="?page='.$first.$link.'&gid='.$gid.'">首页</a></li>';
echo '<li><a href="?page='.$prev.$link.'&gid='.$gid.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="?page='.$i.$link.'&gid='.$gid.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="?page='.$i.$link.'&gid='.$gid.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="?page='.$next.$link.'&gid='.$gid.'">&raquo;</a></li>';
echo '<li><a href="?page='.$last.$link.'&gid='.$gid.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';

?>
</div>
</div>
</div>
</div>
<?php
	}
	//include('footer.php');
	
?>
<script>
function qiyong(id){
	var doc = $('.line-id-'+id+' .showstatus');
	if(doc.attr('data') == "1"){
		doc.html("已禁用").attr({'data':'0'});
	}else{
		doc.html("已启用").attr({'data':'1'});
	}
	var url = "list_line.php?act=show";
		var data = {
			"id":id,
			"show":doc.attr('data')
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("操作失败");
			}
		},"JSON");
}
function delLine(id){
	if(confirm('确认删除吗？删除后不可恢复哦！')){
		$('.line-id-'+id).slideUp();
		var url = "list_line.php?act=del";
		var data = {
			"id":id
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("删除失败");
			}
		},"JSON");
	}
}
</script>