-- phpMyAdmin SQL Dump
-- version 4.4.15.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2017-01-20 22:46:00
-- 服务器版本： 5.5.48-log
-- PHP Version: 5.4.45

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ov`
--

-- --------------------------------------------------------

--
-- 表的结构 `app_admin`
--

CREATE TABLE IF NOT EXISTS `app_admin` (
  `id` int(11) NOT NULL,
  `op` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `app_admin`
--

INSERT INTO `app_admin` (`id`, `op`, `username`, `password`) VALUES
(1, '0', 'admin', 'admin');

-- --------------------------------------------------------

--
-- 表的结构 `app_bbs`
--

CREATE TABLE IF NOT EXISTS `app_bbs` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `username` text NOT NULL,
  `to` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `app_config`
--

CREATE TABLE IF NOT EXISTS `app_config` (
  `id` int(11) NOT NULL,
  `system` text NOT NULL,
  `qq` text NOT NULL,
  `top_content` text NOT NULL,
  `no_limit` text NOT NULL,
  `reg` int(11) NOT NULL,
  `col1` text NOT NULL,
  `col2` text NOT NULL,
  `col3` text NOT NULL,
  `col4` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `app_daili`
--

CREATE TABLE IF NOT EXISTS `app_daili` (
  `id` int(11) NOT NULL,
  `default` int(11) NOT NULL,
  `qq` text NOT NULL,
  `conetnt` text NOT NULL,
  `chongzhi` text NOT NULL,
  `name` text NOT NULL,
  `pass` text NOT NULL,
  `web` text NOT NULL,
  `show` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `app_data`
--

CREATE TABLE IF NOT EXISTS `app_data` (
  `id` int(11) NOT NULL,
  `key` char(255) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `app_data`
--

INSERT INTO `app_data` (`id`, `key`, `value`) VALUES
(1, 'TCP_PATH', 'res/user-status.txt'),
(2, 'UDP_PATH', 'res/user-status-udp.txt');

-- --------------------------------------------------------

--
-- 表的结构 `app_gg`
--

CREATE TABLE IF NOT EXISTS `app_gg` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `app_qq`
--

CREATE TABLE IF NOT EXISTS `app_qq` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `app_read`
--

CREATE TABLE IF NOT EXISTS `app_read` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `readid` text NOT NULL,
  `time` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `auth_config`
--

CREATE TABLE IF NOT EXISTS `auth_config` (
  `id` varchar(80) NOT NULL DEFAULT '1',
  `gg` text,
  `ggs` text,
  `dl1` float DEFAULT NULL COMMENT 'vip1',
  `dl2` float DEFAULT NULL COMMENT 'vip2',
  `dl3` float DEFAULT NULL COMMENT 'vip3',
  `dl4` float DEFAULT NULL COMMENT 'vip4',
  `dl5` float DEFAULT NULL COMMENT 'vip5',
  `dl0` float DEFAULT NULL COMMENT 'vip0',
  `dls1` float NOT NULL,
  `dls2` float NOT NULL,
  `dls3` float NOT NULL,
  `dls4` float NOT NULL,
  `dls5` float NOT NULL,
  `dls0` float NOT NULL,
  `regok` int(11) DEFAULT NULL,
  `activeok` int(11) DEFAULT NULL,
  `ok` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `auth_config`
--

INSERT INTO `auth_config` (`id`, `gg`, `ggs`, `dl1`, `dl2`, `dl3`, `dl4`, `dl5`, `dl0`, `dls1`, `dls2`, `dls3`, `dls4`, `dls5`, `dls0`, `regok`, `activeok`, `ok`) VALUES
('1', '231123546', '31222222', 3, 0.01, 2.5, 2, 1.5, 7, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `auth_daili`
--

CREATE TABLE IF NOT EXISTS `auth_daili` (
  `id` int(255) NOT NULL,
  `tj_rmb` decimal(11,2) NOT NULL,
  `tj_user` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vip` int(11) DEFAULT NULL,
  `kmlist` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_kms`
--

CREATE TABLE IF NOT EXISTS `auth_kms` (
  `id` int(11) NOT NULL,
  `kind` tinyint(1) NOT NULL DEFAULT '1',
  `daili` int(11) NOT NULL DEFAULT '0',
  `km` varchar(64) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `values` decimal(11,2) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT '0.00',
  `isuse` tinyint(1) DEFAULT '0',
  `user` varchar(50) DEFAULT NULL,
  `usetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_log`
--

CREATE TABLE IF NOT EXISTS `auth_log` (
  `id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `line`
--

CREATE TABLE IF NOT EXISTS `line` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `type` text NOT NULL,
  `group` text NOT NULL,
  `show` int(11) NOT NULL,
  `label` text NOT NULL,
  `time` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `line`
--

INSERT INTO `line` (`id`, `name`, `content`, `type`, `group`, `show`, `label`, `time`) VALUES
(1, '证书', 'dev tun\r\nproto udp\r\nremote 59.111.101.156 1194\r\ncipher AES-128-CBC\r\nauth SHA1\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\nclient\r\nverb 3\r\nauth-user-pass\r\n<ca>\r\n-----BEGIN CERTIFICATE-----\r\nMIID9DCCAtygAwIBAgIBADANBgkqhkiG9w0BAQsFADB5MSIwIAYDVQQDDBlhc2Qt\r\nOTE1ODI3LTE3ZWU5NDdjLTV0eGZ6MSIwIAYDVQQKDBlhc2QtOTE1ODI3LTE3ZWU5\r\nNDdjLTV0eGZ6MSIwIAYDVQQLDBlhc2QtOTE1ODI3LTE3ZWU5NDdjLTV0eGZ6MQsw\r\nCQYDVQQGEwJVUzAeFw0xNzAxMTkwNTA0MTZaFw0zNzEyMzEwNTA0MTZaMHkxIjAg\r\nBgNVBAMMGWFzZC05MTU4MjctMTdlZTk0N2MtNXR4ZnoxIjAgBgNVBAoMGWFzZC05\r\nMTU4MjctMTdlZTk0N2MtNXR4ZnoxIjAgBgNVBAsMGWFzZC05MTU4MjctMTdlZTk0\r\nN2MtNXR4ZnoxCzAJBgNVBAYTAlVTMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB\r\nCgKCAQEAqZ62wIDM7+IwYWfzKjjdeWn5WCmcskwz/nYN0G7hEkuKD3GUq718o+pm\r\nLVkTLJaemO+jdwnSx+dGf1N3gAcWBXPYn78WxeVCiICrd4CeHHD7LQ+yEpCzwniB\r\np2FWyGFz6XmnAuXRUcg0Vib+89aBcqwb1lDPjH8AdXpL2vBAdQqfHGD5Ewqe0+6m\r\nJmb4sdGhI90id23SEqpEFFRSn+3gW8HmLPuDg35EGNtI/hzxUp99u8KJca688Sho\r\nwhgX3XVATZ1qCbMZUSJxQaq88dEyGEL2KMoimbpfD86umcv2LV252qPhhpmbrLGP\r\nnyOUc4/CsozJOMCwVhrr4QHv8YMs6QIDAQABo4GGMIGDMA8GA1UdEwEB/wQFMAMB\r\nAf8wCwYDVR0PBAQDAgH2MGMGA1UdJQRcMFoGCCsGAQUFBwMBBggrBgEFBQcDAgYI\r\nKwYBBQUHAwMGCCsGAQUFBwMEBggrBgEFBQcDBQYIKwYBBQUHAwYGCCsGAQUFBwMH\r\nBggrBgEFBQcDCAYIKwYBBQUHAwkwDQYJKoZIhvcNAQELBQADggEBAFF83Du2fxYx\r\nL9hkiGklCc5KyEjNefmrXPpAbKZxPlMzV5198JDp+1XY1US0pZVablkWWo5Ov8G8\r\nJhZuVtRUYREwGwpknGiuR7XDp5EGFIHhscpGGy073GL5lvRyxSyVJ/OWfYHAACuK\r\nFoMKnCPfH2zETBLSFCQqWh+6dIbw4lQP5d0J9flqZKL0fmGRavNBb3ks8+b6jdKh\r\nqNm9f++iotuCckSzik/atjcPXRfLMHRsk17DcGNxMfl+I39ubp/vxeS/XMtiv75i\r\ngf/VWa1nbFz9EJWnJ6LfTHFzFtpbVJxpy/2pzYO0ElQrObkqxIQf4nM/asKBrsBy\r\nfUKRw+avGn0=\r\n-----END CERTIFICATE-----\r\n\r\n</ca>\r\n\r\n<cert>\r\n-----BEGIN CERTIFICATE-----\r\nMIID1jCCAr6gAwIBAgIBADANBgkqhkiG9w0BAQsFADBqMR0wGwYDVQQDDBQxMjc5\r\nMTY3OTg3NTQ2Mjk2MTc3MDEdMBsGA1UECgwUMTI3OTE2Nzk4NzU0NjI5NjE3NzAx\r\nHTAbBgNVBAsMFDEyNzkxNjc5ODc1NDYyOTYxNzcwMQswCQYDVQQGEwJVUzAeFw0x\r\nNzAxMTkwNTE5MzZaFw0zNzEyMzEwNTE5MzZaMGoxHTAbBgNVBAMMFDEyNzkxNjc5\r\nODc1NDYyOTYxNzcwMR0wGwYDVQQKDBQxMjc5MTY3OTg3NTQ2Mjk2MTc3MDEdMBsG\r\nA1UECwwUMTI3OTE2Nzk4NzU0NjI5NjE3NzAxCzAJBgNVBAYTAlVTMIIBIjANBgkq\r\nhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAv2Zqip4ZptFHWSL8F2QEOX+Ix/gl7elD\r\nAaU4EirvQYLXKX8UF/nb2jmvoZ1ccMv5YuOmqJVgTHubap7A04UrrxQBD0usakuH\r\nwiqkpoj+TgA5M9PYhbpdUccGmSSM1zNg/Sm8cOKYrhqgfrl2VqiPGgzRHKQ3HqCy\r\no2uzCPr/vpjOVOHG34rtAI/3xQwHv1A8IuqKUTg8WLWmuhzauwUzX4L82iu0sN70\r\nPktHhMqZsYwqhxoBzuW66LaurNiTUCYRDnBZwYGI+eR1aNEbZSqYge+2ronBfGC1\r\n8I6Ssn5td+2osVDdJd2Fskb2m2Hrc+D258YxVlJ0+nUU/kxPDxnIkwIDAQABo4GG\r\nMIGDMA8GA1UdEwEB/wQFMAMBAf8wCwYDVR0PBAQDAgH2MGMGA1UdJQRcMFoGCCsG\r\nAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUFBwMEBggrBgEFBQcDBQYI\r\nKwYBBQUHAwYGCCsGAQUFBwMHBggrBgEFBQcDCAYIKwYBBQUHAwkwDQYJKoZIhvcN\r\nAQELBQADggEBAGpuxW6KcFbXL5XZGxR5MfwnZ9C5rNmTR7OZOaG2PLH8DukFwoDG\r\nTEXx7zfEO+4L31GqKl4ywIh7DYeUmmnh8z3zZ+mHz53Gw72qeiY/xgz5EVNTOxRS\r\nYS4QZzP/KvtCgWe6C4AFOrWHzHI7xkDgMkomSFwVaQcR+ydZNNUVr8QGeGTCvMZT\r\nSZriZKh1VNOV+ipMVN6hSOVRk/j3p2v9C3ufWvhMWzOXqKjggIQ6wkNsauPi39WT\r\nc3Vxx0ouJzNf6ixgFylmUDhVx8D61OdP5yQTsyYR8a7beu6DGgylJFLy8chhm5T8\r\n4TJV9XInzzJAxyuSlynkfA4GpCVa26QRwDk=\r\n-----END CERTIFICATE-----\r\n\r\n</cert>\r\n\r\n<key>\r\n-----BEGIN PRIVATE KEY-----\r\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC/ZmqKnhmm0UdZ\r\nIvwXZAQ5f4jH+CXt6UMBpTgSKu9BgtcpfxQX+dvaOa+hnVxwy/li46aolWBMe5tq\r\nnsDThSuvFAEPS6xqS4fCKqSmiP5OADkz09iFul1RxwaZJIzXM2D9Kbxw4piuGqB+\r\nuXZWqI8aDNEcpDceoLKja7MI+v++mM5U4cbfiu0Aj/fFDAe/UDwi6opRODxYtaa6\r\nHNq7BTNfgvzaK7Sw3vQ+S0eEypmxjCqHGgHO5brotq6s2JNQJhEOcFnBgYj55HVo\r\n0RtlKpiB77auicF8YLXwjpKyfm137aixUN0l3YWyRvabYetz4PbnxjFWUnT6dRT+\r\nTE8PGciTAgMBAAECggEAdLDoO+LwGLh3G20s7MXZnYSXy/MKjOYuKA6nBMyQWgx/\r\nSZlkksmOtJl+7rWV6l8xiIzqytVnhLnHo1Vukocafv9fNggY8iVie4qsH6xd/wg7\r\n19FMrRtWUclZyHx0Ma/tbevIK7q7A0rQlvJTp7nUpTkzNJcZ0959iwzadpsw2O4a\r\npNteAlaDum8EFe3w6f5+X/ubRFs1V/dwcE4RavivuvD06SJCv2GRlZj8HHZiPdbk\r\nlzbjp7ST8LXBc5Ppo+nMX1qNACDar+A9LLKZZnwND7qXNlsg4Xzy2pM2KuaYz2C9\r\nsHPlPPOvjGTuIBeJoBy1Bu/G/uSdo680wSSBg3TC4QKBgQDlskZjC5R0iXeaXdTn\r\ngfO/3Hupv9C5dtYjcfPBmV5QHivKo28D3cXdbm8XOr8ugXNw1l5jlAhMW/YGE/zP\r\ncPMck817cbYFbM3NoMnZ6Ui+lwLqerCw6o3YmCcm/9dCS10qfbF26ACckblExveQ\r\nlIDyfWDOW51rVUZ8R1/hhSpP9wKBgQDVUXSLfU99Wqfq954BQXCgeM4xefbdTcnU\r\nKoSuqlBF0tpjR0XG1CWQWJ8N8C0aOhwk2pzYiwdI8ev7ZKu0V6EnheTVRf49WdA4\r\n7vWB9R6yCqeo2u3AZpPEDaiw4WTYQRUpzOULxMoYqrzVmaOsmmUId5bjTuX1XxVg\r\nJqD2IybdRQKBgHq+KmjRDlK8BuLBk3zm76cuHhMWwmXpQAMO6LAi0chEZyhQ74kE\r\nYLC0S78BEJq8aED6/NN/jnOnjK+wzJ7Zf8Bcpyh5GkiJ3OwuKM8+nzXhophEWdkg\r\nbg45OGrZumDdvvpu0n90+KayJGvBWxeyk7mBEFMVl+h8WD8fMPhlXbf/AoGBANGF\r\nCgWf9R1Yl6mPwJ/XGLplLZEnDDPdnalIgb3VBrcuHNZ6QKzD3oliogbcqlAiV1ZT\r\nas6970/UXkYzYPrnPyBEwLhB4S99MalZ+8XDbnzNPlP5hJ//oI9mIxRordZCRnki\r\nCK6AgUetG4BpQXvcwfOJEqj8650P4TzpdBuN9zRJAoGBAItoVmTvESAxRzHZvs+w\r\ny9VdL0kXmnNKZdsXOlo+pwILbedtgsW5EqD+t+ZrWZJLhtewWnQrC7EDTf0E+n84\r\niJOgzhAZe2wsKDVThxnuowxHkt8dh90LK71VY8Ga+It3YXBRLBta1SqgH6TGNLex\r\nI5MhYJK+xf0+xDWWX9wpG3Cn\r\n-----END PRIVATE KEY-----\r\n\r\n</key>\r\n', '证书', '1', 1, '证书', '1484899137');

-- --------------------------------------------------------

--
-- 表的结构 `line_grop`
--

CREATE TABLE IF NOT EXISTS `line_grop` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8mb4_bin NOT NULL,
  `show` int(11) NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 转存表中的数据 `line_grop`
--

INSERT INTO `line_grop` (`id`, `name`, `show`, `order`) VALUES
(1, '中国移动', 1, 1),
(2, '中国电信', 1, 1),
(3, '中国联通', 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE IF NOT EXISTS `openvpn` (
  `id` int(11) NOT NULL,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `down` int(11) DEFAULT '0',
  `upload` int(11) DEFAULT '0',
  `logins` int(11) DEFAULT '0',
  `online` int(1) NOT NULL,
  `osent` bigint(128) DEFAULT '0',
  `orecv` bigint(128) DEFAULT '0',
  `mode` varchar(16) NOT NULL,
  `sid` varchar(30) NOT NULL,
  `dlid` int(11) DEFAULT NULL,
  `tian` int(11) NOT NULL COMMENT '??ǰ?ѷ???'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `id` int(11) NOT NULL,
  `ip` varchar(16) CHARACTER SET utf8 DEFAULT NULL,
  `sent` bigint(128) NOT NULL DEFAULT '0',
  `recv` bigint(128) NOT NULL DEFAULT '0',
  `online` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `server_list`
--

CREATE TABLE IF NOT EXISTS `server_list` (
  `id` int(11) NOT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `user` varchar(20) DEFAULT NULL,
  `sent` bigint(128) NOT NULL DEFAULT '0',
  `recv` bigint(128) NOT NULL DEFAULT '0',
  `osent` bigint(128) NOT NULL DEFAULT '0',
  `orecv` bigint(128) NOT NULL DEFAULT '0',
  `online` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `top`
--

CREATE TABLE IF NOT EXISTS `top` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `data` bigint(20) NOT NULL,
  `time` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_admin`
--
ALTER TABLE `app_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_bbs`
--
ALTER TABLE `app_bbs`
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_config`
--
ALTER TABLE `app_config`
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_daili`
--
ALTER TABLE `app_daili`
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_data`
--
ALTER TABLE `app_data`
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_gg`
--
ALTER TABLE `app_gg`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_3` (`id`);

--
-- Indexes for table `app_qq`
--
ALTER TABLE `app_qq`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_3` (`id`);

--
-- Indexes for table `app_read`
--
ALTER TABLE `app_read`
  ADD KEY `id` (`id`);

--
-- Indexes for table `auth_config`
--
ALTER TABLE `auth_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_daili`
--
ALTER TABLE `auth_daili`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_kms`
--
ALTER TABLE `auth_kms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `km` (`km`);

--
-- Indexes for table `auth_log`
--
ALTER TABLE `auth_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `line`
--
ALTER TABLE `line`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `line_grop`
--
ALTER TABLE `line_grop`
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `openvpn`
--
ALTER TABLE `openvpn`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `iuser` (`iuser`);

--
-- Indexes for table `server`
--
ALTER TABLE `server`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `server_list`
--
ALTER TABLE `server_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top`
--
ALTER TABLE `top`
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_admin`
--
ALTER TABLE `app_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `app_bbs`
--
ALTER TABLE `app_bbs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_config`
--
ALTER TABLE `app_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_daili`
--
ALTER TABLE `app_daili`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_data`
--
ALTER TABLE `app_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `app_gg`
--
ALTER TABLE `app_gg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `app_qq`
--
ALTER TABLE `app_qq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_read`
--
ALTER TABLE `app_read`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `auth_daili`
--
ALTER TABLE `auth_daili`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `auth_kms`
--
ALTER TABLE `auth_kms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `auth_log`
--
ALTER TABLE `auth_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `line`
--
ALTER TABLE `line`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `line_grop`
--
ALTER TABLE `line_grop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `openvpn`
--
ALTER TABLE `openvpn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `server`
--
ALTER TABLE `server`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `server_list`
--
ALTER TABLE `server_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `top`
--
ALTER TABLE `top`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
