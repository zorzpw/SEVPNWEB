<?php @eval("//Encode by  phpjiami.com,Free user."); ?><?php
header("location: ./user/login.php");