#!/bin/sh
curl "http://192.168.1.1:8888/app_api/top_api.php?name=$1&s=$2&r=$3&version=1"
