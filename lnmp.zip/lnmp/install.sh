#!/bin/bash
cur_dir=$(pwd)
export cur_dir
mkdir -p /home/wwwroot/default
mkdir -p /home/wwwlog/
./include/init.sh
./include/install_nginx.sh
./include/install_php.sh
./include/install_mysql.sh
