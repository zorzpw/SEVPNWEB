#!/bin/bash

# 安装ngixn
wget -O /etc/yum.repos.d/nginx.repo http://updatelk.4gml.com/v2/REP/nginx.repo >/dev/null 2>&1
yum -y install nginx
mv /usr/share/nginx /home/wwwroot
cp -r ${cur_dir}/conf/default.conf /etc/nginx/conf.d/default.conf
systemctl enable nginx.service
systemctl start nginx.service
