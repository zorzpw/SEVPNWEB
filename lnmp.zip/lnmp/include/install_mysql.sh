#!/bin/bash

# 安装mysql
yum install -y mariadb mariadb-server
systemctl restart mariadb.service
systemctl enable mariadb.service
